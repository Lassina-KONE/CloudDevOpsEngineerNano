Deploy Static Website on AWS
============================

website url: http://mr.destinations.s3.eu-west-3.amazonaws.com/index.html

